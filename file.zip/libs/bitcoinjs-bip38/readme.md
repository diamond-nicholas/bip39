Build (will create a bundle and copy it to /tmp/bitcoinjs-bip38.js):

    npm install
    npm run build
